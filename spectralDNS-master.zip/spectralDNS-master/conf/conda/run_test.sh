#!bin/bash
pushd tests
py.test -v
